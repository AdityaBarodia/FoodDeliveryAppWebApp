let movies = [
 {
    name: "Explore the Wide Menu",
    des:
      "An array of tantalizing dishes, each a masterpiece of flavor and presentation, awaits to delight the senses and elevate your dining experience to new heights.",
    image:
      "https://raw.githubusercontent.com/AdityaBarodia/FoodDeliveryWebApp/main/images/photo5.jpg"
  },
  {
    name: "Escape from the Workplace??",
    des:
      "Experience the enchantment of our cozy bistro, where delectable dishes and inviting atmosphere create the perfect setting for a memorable night out.",
    image:
      "https://raw.githubusercontent.com/AdityaBarodia/FoodDeliveryWebApp/main/images/photo1.jpg"
  },
  {
    name: "Capture the essence",
    des:
      "Intimate candlelit tables nestled beneath warm, rustic beams, inviting guests to linger and savor the cozy charm of our restaurant's welcoming interior.",
    image:
      "https://raw.githubusercontent.com/AdityaBarodia/FoodDeliveryWebApp/main/images/photo2.jpg"
  },
  {
    name: "Store Front",
    des:
      "Radiating with charm, our restaurant's facade beckons with welcoming lights and inviting ambiance, promising an unforgettable dining experience from the moment you arrive.",
    image:
      "https://raw.githubusercontent.com/AdityaBarodia/FoodDeliveryWebApp/main/images/photo3.jpg"
  },
  {
    name: "Spacious Interior",
    des:
      "Immerse yourself in the intimate ambiance of our restaurant, where every corner whispers tales of culinary delight and shared memories, creating an unforgettable dining experience.",
    image:
      "https://raw.githubusercontent.com/AdityaBarodia/FoodDeliveryWebApp/main/images/photo4.jpg"
  }
];

const carousel = document.querySelector(".carousel");
let sliders = [];

let slideIndex = 0; // to track current slide index.

const createSlide = () => {
  if (slideIndex >= movies.length) {
    slideIndex = 0;
  }

  // creating DOM element
  let slide = document.createElement("div");
  var imgElement = document.createElement("img");
  let content = document.createElement("div");
  let h1 = document.createElement("h1");
  let p = document.createElement("p");

  // attaching all elements
  imgElement.appendChild(document.createTextNode(""));
  h1.appendChild(document.createTextNode(movies[slideIndex].name));
  p.appendChild(document.createTextNode(movies[slideIndex].des));
  content.appendChild(h1);
  content.appendChild(p);
  slide.appendChild(content);
  slide.appendChild(imgElement);
  carousel.appendChild(slide);

  // setting up image
  imgElement.src = movies[slideIndex].image;
  slideIndex++;

  // setting elements classname
  slide.className = "slider";
  content.className = "slide-content";
  h1.className = "movie-title";
  p.className = "movie-des";

  sliders.push(slide);

  if (sliders.length) {
    sliders[0].style.marginLeft = `calc(-${100 * (sliders.length - 2)}% - ${
      30 * (sliders.length - 2)
    }px)`;
  }
};

for (let i = 0; i < 3; i++) {
  createSlide();
}

setInterval(() => {
  createSlide();
}, 3000);
const videoCards = [...document.querySelectorAll(".video-card")];

videoCards.forEach((item) => {
  item.addEventListener("mouseover", () => {
    let video = item.children[1];
    video.play();
  });
  item.addEventListener("mouseleave", () => {
    let video = item.children[1];
    video.pause();
  });
});
let cardContainers = [...document.querySelectorAll(".card-container2")];
let preBtns = [...document.querySelectorAll(".pre-btn")];
let nxtBtns = [...document.querySelectorAll(".nxt-btn")];

cardContainers.forEach((item, i) => {
  let containerDimensions = item.getBoundingClientRect();
  let containerWidth = containerDimensions.width;

  nxtBtns[i].addEventListener("click", () => {
    item.scrollLeft += containerWidth - 200;
  });

  preBtns[i].addEventListener("click", () => {
    item.scrollLeft -= containerWidth + 200;
  });
});

	


var incrementButton = document.getElementsByClassName("inc");
var decrementButton = document.getElementsByClassName("dec");
console.log(incrementButton);
console.log(decrementButton);
for(var i=0; i<incrementButton.length; i++){
	var button = incrementButton[i];
	button.addEventListener('click',function(event){
		var buttonClicked = event.target;
		var input = buttonClicked.parentElement.children[1];
		console.log(input);
		var inputValue = input.value;
		var newValue = parseInt(inputValue)+1;
		input.value = newValue;
	})
}
for(var i=0; i<decrementButton.length; i++){
	var button = decrementButton[i];
	button.addEventListener('click',function(event){
		var buttonClicked = event.target;
		var input = buttonClicked.parentElement.children[1];
		//console.log(input);
		var inputValue = input.value;
		var newValue = parseInt(inputValue)-1;
		if(newValue >= 0 ){
			input.value = newValue;
		}
		else{
			input.value = 0;
		}
	})
}
