import java.util.ArrayList;

public class CartList {
	public static ArrayList<Dish> checkOutList = new ArrayList<Dish>();
	
	public static void printList() {
		for(Dish d : checkOutList) {
			System.out.println(d.quantity);
		}
	}
}
