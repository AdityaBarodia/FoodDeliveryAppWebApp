package demoPackage;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.Iterator;

import demoPackage.CartList;
import demoPackage.Dish;

/**
 * Servlet implementation class ItemUpdateServlet
 */
public class ItemUpdateServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	    Iterator<Dish> iterator = CartList.checkOutList.iterator();
	    while (iterator.hasNext()) {
	        Dish d = iterator.next();
	        String quantityStr = request.getParameter(d.dish_ID);
	        if (quantityStr != null) {
	            try {
	                int quantity = Integer.parseInt(quantityStr);
	                if (quantity == 0) {
	                    d.quantity = 0;
	                    iterator.remove(); // Safely removes the dish from the list
	                } else {
	                    if (quantity != d.quantity) {
	                        d.quantity = quantity;
	                    }
	                }
	            } catch (NumberFormatException e) {
	                // Handle the exception or log the error
	                System.err.println("Invalid quantity for dish ID: " + d.dish_ID);
	            }
	        }
	    }
	    request.getRequestDispatcher("cart.jsp").forward(request, response);
	}

}
