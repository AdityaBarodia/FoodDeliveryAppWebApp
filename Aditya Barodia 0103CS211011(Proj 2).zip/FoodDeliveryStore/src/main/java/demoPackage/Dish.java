package demoPackage;
public class Dish {
	public String dishName;
	public int price;
	public int quantity;
	public String dish_ID;
	
	public int returnFinalPrice() {
		return (this.price * this.quantity);	
	}
}
