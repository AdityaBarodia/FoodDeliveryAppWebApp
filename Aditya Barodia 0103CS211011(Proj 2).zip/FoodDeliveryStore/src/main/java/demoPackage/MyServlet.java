package demoPackage;
import com.database.DbConnection;
import demoPackage.CartList;
import demoPackage.Dish;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

/**
 * Servlet implementation class MyServlet
 */
public class MyServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		try{
			//System.out.println("Hello from Servlet");
			Connection con = DbConnection.takeConnection();
			String query = "select * from dishes";
			PreparedStatement ps = con.prepareStatement(query);
			ResultSet rs = ps.executeQuery();
			//System.out.println("Query Executed");
			while(rs.next()){
				//System.out.println("Inside Loop");
				int quantity = Integer.parseInt(request.getParameter(rs.getString(1)));
				//System.out.println(quantity);
				String dishID = rs.getString(1);
				
				
				if(CartList.dishMap.containsKey(dishID)) { //object already initialized
					CartList.dishMap.get(dishID).quantity = quantity; //update quantity
					CartList.checkOutList.remove(CartList.dishMap.get(dishID));
					if(quantity!=0) {
						CartList.checkOutList.add(CartList.dishMap.get(dishID));
					}
				}
				else { //object not initialized
					if(quantity!=0) {
						CartList.dishMap.put(dishID, new Dish());
						CartList.dishMap.get(dishID).dish_ID = rs.getString(1); 
						CartList.dishMap.get(dishID).dishName = rs.getString(2);
						CartList.dishMap.get(dishID).price = rs.getInt(3);
						CartList.dishMap.get(dishID).quantity = quantity;
						CartList.checkOutList.add(CartList.dishMap.get(dishID));
					}
				}
			}
		}
		catch(Exception e){
		}
		
		//request.setAttribute("recommendedMovies",recommendedMovies);
		CartList.printList();
        request.getRequestDispatcher("cart.jsp").forward(request, response);
	}

}
