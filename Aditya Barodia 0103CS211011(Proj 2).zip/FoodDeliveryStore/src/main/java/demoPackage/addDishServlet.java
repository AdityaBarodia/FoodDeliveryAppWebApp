package demoPackage;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import com.database.*;

/**
 * Servlet implementation class addDishServlet
 */
public class addDishServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		String dish_type = request.getParameter("dish_type");
		String dishID = request.getParameter("dishID");
		String dish_name = request.getParameter("dish_name");
		int dish_price = Integer.parseInt(request.getParameter("dish_price"));
		String dish_description = request.getParameter("dish_description");
		String dish_image = request.getParameter("dish_image");
		
		DbConnection.addNewDish(dishID,dish_name,dish_price,dish_description,dish_image,dish_type);
		request.getRequestDispatcher("adminControl.jsp").forward(request, response);
	}

}
