package demoPackage;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class CartList {
	public static ArrayList<Dish> checkOutList = new ArrayList<Dish>();
	public static Map<String,Dish> dishMap = new HashMap<>();
	
	public static void printList() {
		for(Dish d : checkOutList) {
			System.out.println(d.dishName);
			System.out.println(d.quantity);
		}
	}
}
