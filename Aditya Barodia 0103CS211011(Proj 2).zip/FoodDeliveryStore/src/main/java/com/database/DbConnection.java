package com.database;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import demoPackage.*;


public class DbConnection {
	public static Connection takeConnection() {
		Connection con = null;
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			String path="jdbc:mysql://localhost:3306/fooddelivery";
			String user="root";
			String pass="root";
			con = DriverManager.getConnection(path,user,pass);
		}
		catch(Exception e) {
			e.printStackTrace();
		}
		return con;
	}
	
	public static int adminChecker(String email, String password) {
	    int status = 0;
	    try {
	        Connection con = takeConnection();
	        String query = "select * from admins where email = ? and password = ?";
	        PreparedStatement ps = con.prepareStatement(query);
	        ps.setString(1, email);
	        ps.setString(2, password);
	        
	        ResultSet rs = ps.executeQuery();
	        if (rs.next()) {
	            status = 1; // User authenticated successfully
	        }
	    } catch (Exception e) {
	        e.printStackTrace();
	    } 
	    return status;
	}
	
	public static int customerChecker(long phone_num, String password) {
	    int status = 0;
	    try {
	        Connection con = takeConnection();
	        String query = "select * from customers where phone_num = ? and password = ?";
	        PreparedStatement ps = con.prepareStatement(query);
	        ps.setLong(1, phone_num);
	        ps.setString(2, password);
	        
	        ResultSet rs = ps.executeQuery();
	        if (rs.next()) {
	            status = 1; // User authenticated successfully
	        }
	    } catch (Exception e) {
	        e.printStackTrace();
	    }
	    
	    return status;
	}

	public static void addNewDish(String dishID, String dish_name, int dish_price, String dish_description,
			String dish_image, String dish_type) {
		try {
	        Connection con = takeConnection();
	        String query = "insert into dishes(dishID,dish_name,dish_price,dish_description,dish_image,dish_type)"
	        		+ "values(?,?,?,?,?,?)";
	        PreparedStatement ps = con.prepareStatement(query);
	        ps.setString(1, dishID);
	        ps.setString(2, dish_name);
	        ps.setInt(3, dish_price);
	        ps.setString(4, dish_description);
	        ps.setString(5, dish_image);
	        ps.setString(6, dish_type);
	        ps.execute();
	        
	    } catch (Exception e) {
	        e.printStackTrace();
	    }
		
	}

	public static void newUser(long phone_num, String password, String name, String address) {
		try {
	        Connection con = takeConnection();
	        String query = "insert into customers(phone_num,password,name,address)"
	        		+ "values(?,?,?,?)";
	        PreparedStatement ps = con.prepareStatement(query);
	        ps.setLong(1, phone_num);
	        ps.setString(2, password);
	        ps.setString(3, name);
	        ps.setString(4, address);
	        ps.execute();
	        
	    } catch (Exception e) {
	        e.printStackTrace();
	    }
	}
	
	public static void finalOrder(long phone_num,double total) {
		try {
	        Connection con = takeConnection();
	        String query = "insert into orders(phone_num,total)"
	        		+ "values(?,?)";
	        PreparedStatement ps = con.prepareStatement(query);
	        ps.setLong(1, phone_num);
	        ps.setDouble(2, total);
	        ps.execute();
	        
	        for(Dish d : CartList.checkOutList) {
	        	query="insert into items(order_id,dishID,quantity)"
	        			+ "values(LAST_INSERT_ID(),?,?)";
	        	ps = con.prepareStatement(query);
	        	String dishID = d.dish_ID;
	        	int quantity = d.quantity;
		        ps.setString(1, dishID);
		        ps.setDouble(2, quantity);
		        ps.execute();
	        }
	        
	    } catch (Exception e) {
	        e.printStackTrace();
	    }
	}
	
}
