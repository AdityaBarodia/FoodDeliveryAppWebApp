public class Dish {
	public String dish_ID;
	public String dishName;
	public int price;
	public int quantity;
	
	public int returnFinalPrice() {
		return (this.price * this.quantity);	
	}
}
